/**********************************************
  These functions will provide management of the permanent storage.
  Each product must have a unique name and unique integer id.
  It can contain whateever else you want.  Orders must have a unique integer id.
  This web page must be where the Json files are stored.
**********************************************/

function showEverything() {
  let output = `<h2 class="elementDescription">Everything in storage (${window.localStorage.length})</h2>`;

  let keys = Object.keys(window.localStorage);
  for (let key of keys) {
    output += `
          <ul class="element-group">
            <li class="element">${key}</li>
            <li class="element">${window.localStorage.getItem(key)}
         </ul>
        `;
  }
  document.getElementById('output').innerHTML = output;
}
function clearOutput() {
  document.getElementById('output').innerHTML = "";
}
// Product functions
function showJsonProducts() {
  fetch('products.json')
    .then((res) => res.json())
    .then((data) => {
      let output = '<h2 class="elementDescription">Json Products</h2>';
      for(var i = 0; i < data.products.length; i++) {
        output += `
          <ul class="element-group">
            <li class="element">${ data.products[i].name}</li>
            <li class="element">${JSON.stringify( data.products[i])}</li>
          </ul>
        `;
      }
      document.getElementById('output').innerHTML = output;
    })
}
function showStoredProducts() {
  let productList = [];

  /* find all the keys and values then choose just products */
  let keys = Object.keys(window.localStorage);
  for (let myKey of keys) {
    if (myKey.startsWith("product-")) {
      let data = window.localStorage.getItem(myKey);
      let object = JSON.parse(data);
      productList.push(object);
    }
  }

  /* they are not in order so sort by id */
  productList.sort(function (a, b) {
    if (a == b.id) return 0;
    if (a.id < b.id) return -1;
    return 1;
  });

  /* display products using the arrays */
  let output = `<h2 class="elementDescription">Products in storage (${productList.length})</h2>`;
  for (let product of productList) {
    let data = JSON.stringify(product);
    output += `
        <ul class="element-group">
          <li class="element">${product.name}</li>
          <li class="element">${data}</li>
        </ul>
      `;
  }
  document.getElementById('output').innerHTML = output;
}
function deleteStoredProducts() {
  let output = `<h2 class="elementDescription">Deleting all products in storage</h2>`;
  let keys = Object.keys(window.localStorage);
  for (let key of keys) {
    if (key.startsWith("product-")) {
      window.localStorage.removeItem(key);
    }
  }
  document.getElementById('output').innerHTML = output;
}
function deleteStorage() {
  let output = `<h2 class="elementDescription">Deleting all contents of storage</h2>`;
  let keys = Object.keys(window.localStorage);
  for (let key of keys) {
    window.localStorage.removeItem(key);
  }
  document.getElementById('output').innerHTML = output;
}
function loadJsonProducts() {
  fetch('products.json')
    .then((res) => res.json())
    .then((data) => {
      let output = '<h2 class="elementDescription">Json Products</h2>';
      for(var i = 0; i < data.products.length; i++) {
        let keyName = "product-" + data.products[i].name;
        let value = JSON.stringify(data.products[i]);
        window.localStorage.setItem(keyName, value);
      }
    })
  let output = `<h2 class="elementDescription">Loading products from Json</h2>`;
  document.getElementById('output').innerHTML = output;
}

// Order functions
function showStoredOrder() {
  // get any order
  let output = `<h2 class="elementDescription">No order in storage</h2>`;
  let objectData = window.localStorage.getItem("order");
  if (objectData != undefined) {
    output = `<h2 class="elementDescription">Bad order in storage</h2>`;
    let order = JSON.parse(objectData);
    if (order != undefined) {
      // display products using the arrays
      output = `<h2 class="elementDescription">Order in storage (${order.item.length} items)</h2>`;
      for (let each of order.item) {
        output += `
          <ul class="element-group">
            <li class="element">Name: ${each.name}</li>
            <li class="element">Price: ${each.price}</li>
          </ul>
        `;
      }
    }
  }
  document.getElementById('output').innerHTML = output;
}
function deleteStoredOrder() {
  window.localStorage.removeItem("order");
  let output = `<h2 class="elementDescription">Deleting all orders in storage</h2>`;
  document.getElementById('output').innerHTML = output;
}
function loadJsonOrder() {
  fetch('order.json')
    .then((res) => res.json())
    .then((data) => {
      let keyName = "order";
      let value = JSON.stringify(data);
      window.localStorage.setItem(keyName, value);
    });
  let output = `<h2 class="elementDescription">Loading order from Json</h2>`;
  document.getElementById('output').innerHTML = output;
}
function showJsonOrder() {
  fetch('order.json')
    .then((res) => res.json())
    .then((data) => {
      let keyName = "order";
      let value = JSON.stringify(data);
      let output = `
        <h2 class="elementDescription">There is an order in Json</h2>
          <ul class="element-group">
            <li class="element">${keyName}</li>
            <li class="element">${value}</li>
          </ul>
       `;
      document.getElementById('output').innerHTML = output;
    })
    .catch((err) => {
      let output = `<h2 class="elementDescription">There is an order in Json</h2>`;
      document.getElementById('output').innerHTML = output;
    })
}
// Table functions
function getStoredProducts(category) {
  let productList = [];

  /* find all the keys and values then choose just products */
  let keys = Object.keys(window.localStorage);
  for (let myKey of keys) {
    if (myKey.startsWith("product-")) {
      let data = window.localStorage.getItem(myKey);
      let object = JSON.parse(data);
      productList.push(object);
    }
  }

  /* they are not in order so sort by id */
  productList.sort(function (a, b) {
    if (a == b.id) return 0;
    if (a.id < b.id) return -1;
    return 1;
  });

  // If no category provided, return the whole list
  if (category == undefined) {
    return productList;
  }
  // Limit to a category, but keep the order by id
  let newProductList = [];
  for (let i = 0; i < productList.length; i++) 
  {
    let myProduct = productList[i];
    if (myProduct.category == category) 
    {
      newProductList.push(myProduct);
    }
  }
  return newProductList;
}
function returnProductsTable() {
  //Get our three food categories 
  let combat = getStoredProducts("combat");
  let potion = getStoredProducts("potion");
  let utility = getStoredProducts("utility");
  let length = Math.max(combat.length,potion.length,utility.length);

  // Add in the table (use code to set its value)
  let output = `<h2 id="productTableTitle">Product Table Title</h2>`;

  // Set up the table header and header columns.  Header names are fixed.
  output += `<table class="productTable">`;

  // Set up the table headers
  output += `
    <thead class="productTableHeader" >
      <tr class="productHeaderRow">
        <th class="productHeaderData">combat</th><th class="productHeaderCost">cost</th>
        <th class="productHeaderData">potion</th><th class="productHeaderCost">cost</th>
        <th class="productHeaderData">utility</th><th class="productHeaderCost">cost</th>
      </tr>
    </thead>`;

  // Setup the body
  output += `<tbody class="productTableBody">`;
  for (let i = 0; i < length; i++)
  {
    output += `<tr class="productTableRow">`;
    if ( i < combat.length ) {
      output += `<td class="productTableItem">${combat[i].name}</td><td class="productTableCost">${combat[i].price}</td>`;
    }
    if ( i < potion.length ) {
      output += `<td class="productTableItem">${potion[i].name}</td><td class="productTableCost">${potion[i].price}</td>`;
    }
    if ( i < utility.length ) {
      output += `<td class="productTableItem">${utility[i].name}</td><td class="productTableCost">${utility[i].price}</td>`;
    }
    output += `</tr>`;
  }

  // No footer, Final tags, return html
  output += `</tbody></table>`;
  return output;
}
function showProductsTable() {
  document.getElementById('output').innerHTML = returnProductsTable();
}
function returnOrderTable() {
  // Get the order or return nothing
  let objectData = window.localStorage.getItem("order");
  if ( objectData == undefined ) return "<h2>no order</h2>";
  let order = JSON.parse(objectData);
  if ( order == undefined ) return "<h2>bad order</h2>";

  // Add in the table (use code to set its value)
  let output = `<h2 id="orderTableTitle">Order Table Title</h2>`;

  // Set up the table header and header columns.  Header names are fixed.
  output += `<table class="orderTable">`;

  // Set up the table headers
  output += `
  <thead class="orderTableHeader" >
    <tr class="orderHeaderRow">
      <th class="orderHeaderData">item</th><th class="orderHeaderCost">cost</th>
    </tr>
  </thead>`;

  // Setup the body
  let total = 0;
  output += `<tbody class="orderTableBody">`;
  for(let i = 0; i < order.item.length; i++)
  {
    total += order.item[i].price;
    output += `
    <tr class="orderTableRow">
      <td class="orderTableItem">${order.item[i].name}</td><td class="orderTableCost">${order.item[i].price}</td>
    </tr>`;
  }
  output += `</tbody>`;

  // Footer
  output += `
  <tfoot class="orderTableFoot">
    <tr class="orderTableFootRow">
      <td class="orderTableFootItem">total</td><td id="orderTotalCost">${total}</td>
    </tr>
  </tfoot>`;

  // // Final tags, return html
  output += `</table>`;
  return output;
}
function showOrderTable() {
  document.getElementById('output').innerHTML = returnOrderTable();
}
// Specific storage access
// Save an object into the local storage with its 'key name' for retrieval
// Do not allow undefine keys or values to be stored
function PutIntoStorage(keyName,object)
{
    if ( keyName != undefined & object != undefined )
    {
        let userData = JSON.stringify(object);
        if ( userData != undefined )
        {
            window.localStorage.setItem(keyName,userData);
        }
    }
}
// Get an object from storage based on its (string) key name
// The return object is already .parsed
function GetFromStorage( keyName )
{
    let objectData = window.localStorage.getItem(keyName);
    if ( objectData == undefined ) return undefined;

    let object = JSON.parse(objectData);
    return object
}
//  Check if an object is in storage, return true or false
function DoesExistInStorage( providedName )
{
    response = false;
    let object = GetFromStorage( providedName );
    if ( object !== undefined ) response = true;
    return response;
}
// Remove an object from the local storage.  No return.  No error if it did not exist.
function DeleteFromStorage(providedName)
{
    localStorage.removeItem(providedName);
}